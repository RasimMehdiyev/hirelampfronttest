<template>


  
  <h1 class="flex justify-center md:text-3xl p-5 font-bold">
  Contact info</h1>


  <div
      class="p-6 md:w-auto xl:w-auto mx-auto flex flex-col xl:items-stretch justify-between xl:flex-row col-end-1"
    >
      <div class="w-full xl:w-1/2 xl:pl-10 xl:py-14 items-start">
        <!-- <button v-on:click="test">TEST v-on</button> -->
        
        <h1
          class="text-2xl md:text-3xl xl:text-3xl font-bold leading-10 text-gray-800 mb-2 text-center xl:text-left md:mt-0 mt-4 sm:mt-0"
        >
          +994 55 430 85 06
        </h1>
        <h1
          class="text-2xl md:text-3xl xl:text-3xl font-bold leading-10 text-gray-800 mb-2 text-center xl:text-left md:mt-0 mt-4 sm:mt-0"
        >
          info@hirelamp.co
        </h1>
         <h1
          class="text-2xl md:text-3xl xl:text-3xl font-bold leading-10 text-gray-800 mb-2 text-center xl:text-left md:mt-0 mt-4 sm:mt-0"
        >
        Uzeyir hajibeyov 57      
       </h1>

      </div>
      <div
        class="xl:w-1/2 md:mb-14 xl:mb-0 relative flex items-center justify-center"
      >
        <img
          src="../assets/Contact.svg"
          alt=""
          class="md:h-100 md:w-1/2 xl:w-1/2 lg:w-1/2 md:my-10 py-10"
        />
      </div>
    </div>




  <div       class="p-6 md:w-auto xl:w-auto mx-auto flex flex-col xl:items-stretch justify-between xl:flex-row col-end-1"
>
    <div class="flex justify-center items-center">
      <!-- <h2 class="text-gray-800 font-bold">
        Email
      </h2>
      <p class="text-gray-800">
        <a href="mailto: -->
           <img
          src="../assets/Contact.svg"
          alt=""
          class="md:h-100 md:w-1/2 xl:w-1/2 lg:w-1/2"
        />
</div>

 <div>
    <!-- <h2>Write us an email and we will get to you within 24 hours</h2> -->
    <div class=" flex flex-row">
   
   <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 md:px-1" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
  <path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
</svg>
<div class="flex flex-row">
<h3>Phone number</h3>
<h3 class="md:px-10">+994554308506</h3>

</div>
    </div>

    <div class=" flex flex-row">
       <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
  <path stroke-linecap="round" stroke-linejoin="round" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
</svg>
<h3>Email address</h3>
    </div>
    <div class=" flex flex-row">
<svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
  <path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
  <path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
</svg>
    <h3>Address</h3>
    </div>
      <div class="flex flex-col justify-center items-center">
                <a href="https://www.linkedin.com/company/hirelampco/" target="_blank" class="flex justify-center items-center">
                <img
          src="../assets/linkedin.svg"
          alt=""
          class="md:h-10 md:w-1/2 xl:w-1/2 lg:w-1/2 h-10 w-1/2" 
        />
        </a>
        <a href="https://instagram.com/hirelampco?igshid=YmMyMTA2M2Y=" target="_blank" class="flex justify-center items-center">
                <img
          src="../assets/instagram.svg"
          alt=""
          class="md:h-10 md:w-1/2 xl:w-1/2 lg:w-1/2 h-10 w-1/2" 
        /></a>
        <a href="https://www.facebook.com/hirelampco/" target="_blank" class="flex justify-center items-center">
                 <img
          src="../assets/facebook.svg"
          alt=""
          class="md:h-10 md:w-1/2 xl:w-1/2 lg:w-1/2 h-10 w-1/2" 
        />
        </a>
              </div>
               </div>
               </div>

  
</template>

<script>
export default {};
</script>

<style></style>
