<template>
  <body
    style="font-family: 'Lato', sans-serif"
    class="sm:py-10 overflow-x-hidden"
  >
    <div
      class="p-6 container md:w-4/5 xl:w-4/5 mx-auto flex flex-col xl:items-stretch justify-between xl:flex-row"
    >
      <div class="w-full xl:w-1/2 xl:pl-10 xl:py-14 items-start">
        <!-- <button v-on:click="test">TEST v-on</button> -->
        <h1
          class="text-2xl md:text-3xl xl:text-3xl font-bold leading-10 text-gray-800 mb-4 text-center xl:text-left md:mt-0 mt-4 sm:mt-0"
        >
          Nail your job interview.
        </h1>
        <h1
          class="text-2xl md:text-3xl xl:text-3xl font-bold leading-10 text-gray-800 mb-4 text-center xl:text-left md:mt-0 mt-2"
        >
          Want to know how?
        </h1>

        <p class="text-lg md:text-2xl">Let us notify you when we are live.</p>
        <form ref="emailForm" @submit.prevent="newsletterPost()">
          <div class="flex items-stretch mt-12 justify-center">
            <input
              class="p-4 sm:p-2 bg-gray-100 rounded-xl rounded-r-none text-base leading-none text-gray-800 w-11/12 border border-transparent focus:outline-none focus:border-gray-500"
              type="email"
              placeholder="Your Email"
              ref="email_newsletter"
              :maxlength="maxChar"
            />
            <button
              class="md:flex justify-center hidden md:visible p-4 sm:p-1 xl:w-auto md:w-auto rounded-l-none hover:bg-blue-700 bg-custom-blue rounded-xl text-base font-medium leading-none text-white uppercase focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-700"
              style="margin-left: -7.8rem"
              stroke-width="100"
              @click="showToast"
            >
              notify me!
            </button>
            <button
              @click="showToast"
              class="p-4 flex justify-center md:hidden visible rounded-l-none hover:bg-blue-700 bg-custom-blue rounded-xl text-base font-medium leading-none text-white uppercase focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-700"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                class="h-10 w-10"
                viewBox="0 0 20 20"
                fill="currentColor"
              >
                <path
                  d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z"
                />
              </svg>
            </button>
          </div>
        </form>
      </div>
      <div
        class="xl:w-1/2 md:mb-14 xl:mb-0 relative h-auto flex items-center justify-center"
      >
        <img
          src="../assets/newsletter1.svg"
          alt="Envelope with a newsletter"
          role="img"
          class="h-80 w-1/2 xl:w-1/2 lg:w-1/2"
        />
      </div>
    </div>
  </body>
</template>

<script>
import axios from "axios";
import { useToast } from "vue-toastification";
// import { useGtm } from '@gtm-support/vue-gtm';

export default {
  name: "HomePage",
  data() {
    return {
      email: "",
      maxChar: 50,
    };
  },

  setup() {
    const toast = useToast();
    return {
      toast,
    };
  },

  methods: {
    newsletterPost() {
      axios.post("http://127.0.0.1:8000/welcome/", {
        email: this.$refs.email_newsletter.value,
      });
      this.$refs.emailForm.reset();
      //this.$refs.form.$el.submit();
      console.log(this.$refs.email_newsletter.value);

      this.$gtm.enabled();

      // console.log(this.email);
    },
    showToast() {
      this.toast.success("Email successfully saved!");
    },

    onClick() {
      this.$gtm.trackEvent({
        event: null, // Event type [default = 'interaction'] (Optional)
        category: "Calculator",
        action: "click",
        label: "Home page SIP calculator",
        value: 1,
        noninteraction: false, // Optional
      });
    },
    mounted() {
      this.$gtm.enabled();
      this.$gtm.trackView("HomePage", "currentPath");
    },
  },
};
</script>
