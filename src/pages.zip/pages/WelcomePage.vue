<template>
  <body style="font-family: 'Lato', sans-serif" class="overflow-x-hidden">
    <Search />

    <div class="bg-gray-100">
      <div>
        <h1 class="flex justify-center md:text-3xl p-5 font-bold">
          Top mentors
        </h1>
        <div
          class="flex flex-row md:flex-nowrap lg:flex-nowrap xl:flex-nowrap flex-wrap justify-center pb-14 px-12"
        >
          <div
            class="w-full md:w-1/2 lg:w-1/3 xl:w-1/4 px-8 py-8 mx-10 md:mx-0 lg:mx-0"
          >
            <div class="bg-gray-300 rounded-3xl p-2 shadow-md">
              <div class="flex flex-col items-center">
                <img
                  src="../assets/user.svg"
                  alt=""
                  class="h-12 md:h-14 lg:h-24 xl:h-28 p-2"
                />
                <h1
                  class="text-md md:text-md lg:text-lg xl:text-lg py-2 font-bold"
                >
                  Nihat Muradzade
                </h1>
                <div class="divide-y divide-dashed divide-gray-400">
                  <div>
                    <p class="text-sm md:text-base lg:text-md xl:text-md pb-3">
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Pellentesque euismod
                    </p>
                  </div>
                  <div class="p-3">
                    <button
                      class="bg-custom-blue text-white px-4 py-1 rounded-3xl text-2xl shadow-sm"
                    >
                      More
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div
            class="w-full md:w-1/2 lg:w-1/3 xl:w-1/4 px-8 py-8 mx-10 md:mx-0 lg:mx-0"
          >
            <div class="bg-gray-300 rounded-3xl p-2 shadow-md">
              <div class="flex flex-col items-center">
                <img
                  src="../assets/user.svg"
                  alt=""
                  class="h-12 md:h-14 lg:h-24 xl:h-28 p-2"
                />
                <h1
                  class="text-md md:text-md lg:text-lg xl:text-lg py-2 font-bold"
                >
                  Nihat Muradzade
                </h1>
                <div class="divide-y divide-dashed divide-gray-400">
                  <div>
                    <p class="text-sm md:text-base lg:text-md xl:text-md pb-3">
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Pellentesque euismod
                    </p>
                  </div>
                  <div class="p-3">
                    <button
                      class="bg-custom-blue text-white px-4 py-1 rounded-3xl text-2xl shadow-sm"
                    >
                      More
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div
            class="w-full md:w-1/2 lg:w-1/3 xl:w-1/4 px-8 py-8 mx-10 md:mx-0 lg:mx-0"
          >
            <div class="bg-gray-300 rounded-3xl p-2 shadow-md">
              <div class="flex flex-col items-center">
                <img
                  src="../assets/user.svg"
                  alt=""
                  class="h-12 md:h-14 lg:h-24 xl:h-28 p-2"
                />
                <h1
                  class="text-md md:text-md lg:text-lg xl:text-lg py-2 font-bold"
                >
                  Nihat Muradzade
                </h1>
                <div class="divide-y divide-dashed divide-gray-400">
                  <div>
                    <p class="text-sm md:text-base lg:text-md xl:text-md pb-3">
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Pellentesque euismod
                    </p>
                  </div>
                  <div class="p-3">
                    <button
                      class="bg-custom-blue text-white px-4 py-1 rounded-3xl text-2xl shadow-sm"
                    >
                      More
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div
            class="w-full md:w-1/2 lg:w-1/3 xl:w-1/4 px-8 py-8 mx-10 md:mx-0 lg:mx-0"
          >
            <div class="bg-gray-300 rounded-3xl p-2 shadow-md">
              <div class="flex flex-col items-center">
                <img
                  src="../assets/user.svg"
                  alt=""
                  class="h-12 md:h-14 lg:h-24 xl:h-28 p-2"
                />
                <h1
                  class="text-md md:text-md lg:text-lg xl:text-lg py-2 font-bold"
                >
                  Nihat Muradzade
                </h1>
                <div class="divide-y divide-dashed divide-gray-400">
                  <div>
                    <p class="text-sm md:text-base lg:text-md xl:text-md pb-3">
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Pellentesque euismod
                    </p>
                  </div>
                  <div class="p-3">
                    <button
                      class="bg-custom-blue text-white px-4 py-1 rounded-3xl text-2xl shadow-sm"
                    >
                      More
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="bg-white pb-10">
        <div class="flex items-center justify-center">
          <div
            class="grid grid-cols-1 md:px-12 md:grid-rows-3 md:grid-cols-2 grid-flow-row md:gap-4 md:justify-center md:items-center"
          >
            <div
              class="mx-8 md:mx-12 justify-content md:text-xl max-w-xl overflow-hidden"
            >
              <h1 class="md:text-lg my-4 md:mx-4 text-gray-600 font-bold">
                Connect with consultants from more than 100 companies and 14
                industries
              </h1>
            </div>
            <div class="md:flex justify-center hidden md:visible">
              <img
                src="../assets/Connect.svg"
                alt=""
                class="h-80 md:w-1/2 xl:w-1/2 lg:w-1/2"
              />
            </div>

            <!-- done -->
            <div class="md:flex justify-center hidden md:visible">
              <img
                src="../assets/Strong.svg"
                alt=""
                class="h-80 md:w-1/2 xl:w-1/2 lg:w-1/2"
              />
            </div>
            <div
              class="my-8 mx-8 justify-content md:text-2xl max-w-xl overflow-hidden md:mx-12"
            >
              <h1 class="md:text-lg my-4 md:mx-4 text-gray-600 font-bold">
                Get feedbacks from industry experts and strengthen your weak
                points
              </h1>
            </div>

            <!-- done -->

            <div
              class="my-8 mx-8 justify-content md:text-2xl max-w-xl overflow-hidden md:mx-12"
            >
              <h1 class="md:text-lg my-4 md:mx-4 text-gray-600 font-bold">
                Maximize your success rate with us
              </h1>
            </div>
            <div class="md:flex justify-center hidden md:visible">
              <img
                src="../assets/Rocket.svg"
                alt=""
                class="h-80 md:w-1/2 xl:w-1/2 lg:w-1/2"
              />
            </div>

            <!-- second row -->
          </div>
        </div>
      </div>

      <Footer />
    </div>
  </body>
</template>

<script>
// import { useGtm } from '@gtm-support/vue-gtm';
// import "vue3-carousel/dist/carousel.css";
// import { Carousel, Slide, Pagination, Navigation } from "vue3-carousel";

//Content for the footer pages
//metors
//what is there for mentors
//how to become a mentor etc

import Search from "../components/Search.vue";
import Footer from "../components/Footer.vue";

export default {
  name: "HomePage",
  data() {
    return {
      email: "",
      maxChar: 50,
    };
  },
  components: {
    // Carousel,
    // Slide,
    // Pagination,
    // Navigation,
    Footer,
    Search,
  },

  methods: {},
};
</script>
