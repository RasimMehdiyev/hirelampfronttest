<template>
  <div>
    <div
      class="p-6 md:w-auto xl:w-auto lg:w-auto mx-auto flex flex-row xl:items-stretch justify-between col-end-1"
    >
      <div
        class="bg-gradient-to-tl from-gray-200 to-gray-100 shadow-md rounded-2xl p-6 md:w-auto xl:w-auto lg:w-auto mx-auto flex flex-col xl:items-stretch justify-between xl:flex-row col-end-1"
      >
        <div class="w:full md:w-full xl:w-1/3">
          <div class="flex flex-col align-center justify-center">
            <img
              v-bind:src="mentorData.profileImg"
              alt=""
              class="px-12 h-20 w-100 md:h-40 md:w-100 xl:w-50 lg:w-50"
            />

            <h1
              class="text-xl md:text-2xl xl:text-3xl font-bold leading-10 text-gray-800 text-center md:mt-0 mt-4 my-2 sm:mt-0"
            >
              {{ mentorData.firstName }} {{ mentorData.lastName }}
            </h1>
            <h1
              class="text-sm md:text-md xl:text-xl leading-10 text-gray-800 text-center md:mt-0 mt-1 sm:mt-0"
            >
              {{ mentorData.industry }}
            </h1>
            <!-- <h1
              class="text-sm md:text-md xl:text-xl leading-10 text-gray-800 text-center md:mt-0 mt-1 sm:mt-0"
            >
              * * * * *
            </h1> -->

            <div
              class="container w-full mx-auto flex items-stretch justify-between flex-row col-end-1 mt-4"
            >
              <div>
                <h1
                  class="text-sm sm:text-sm md:text-base lg:text-md xl:text-md"
                >
                  Location
                </h1>
              </div>
              <div class="flex align-left justify-end">
                <h1
                  class="flex align-left justify-end font-bold text-sm sm:text-sm md:text-base lg:text-md xl:text-md"
                >
                  {{ mentorData.address }}
                </h1>
              </div>
            </div>
            <div
              class="container w-full mx-auto flex items-stretch justify-between flex-row col-end-1"
            >
              <div>
                <h1
                  class="text-sm sm:text-sm md:text-base lg:text-md xl:text-md"
                >
                  Current position
                </h1>
              </div>
              <div class="flex align-left justify-end">
                <h1
                  class="flex align-left justify-end font-bold text-sm sm:text-sm md:text-base lg:text-md xl:text-md"
                >
                  {{ mentorData.currentPosition }}
                </h1>
              </div>
            </div>
            <div>
              <div class="container w-full mx-auto col-end-1 my-1 mt-4">
                <h1
                  class="flex w-full font-bold text-sm sm:text-sm md:text-base lg:text-md xl:text-md justify-start"
                >
                  Services
                </h1>
              </div>
              <div class="container mx-auto col-end-1 my-1">
                <h1
                  class="text-sm sm:text-sm md:text-base lg:text-md text-left xl:text-md pb-3"
                >
                  {{ mentorData.services }}
                </h1>
              </div>
            </div>
          </div>
        </div>
        <!-- <div class="w-1/12">
          <div
            class="flex flex-col align-center justify-center border-l border-gray-900"
          ></div>
        </div> -->
        <div class="w:full md:w-full xl:w-1/3 md:mx-8 lg:mx-8 xl:mx-8">
          <div class="flex flex-col align-center justify-center">
            <h1
              class="text-xl md:text-2xl xl:text-3xl font-bold leading-10 text-gray-800 text-left md:mt-0 mb-4 mt-1 sm:mt-0"
            >
              Bio
            </h1>

            <p
              class="text-sm sm:text-sm md:text-base lg:text-md text-left xl:text-md pb-3"
            >
              {{ mentorData.description }}
            </p>
          </div>
          <div class="align-center justify-center">
            <h1
              class="text-xl md:text-2xl xl:text-3xl font-bold leading-10 text-gray-800 text-left md:mt-0 mb-4 mt-1 sm:mt-0"
            >
              Tags
            </h1>

            <ul
              class="py-2 px-2 text-sm sm:text-sm md:text-base lg:text-md xl:text-md text-left inline-flex content-start justify-start"
              v-for="tag in mentorData.tags"
              :key="tag"
            >
              <!-- class="px-4 py-2 rounded-full text-gray-500 border border-gray-300
              font-semibold text-sm flex align-center w-max cursor-pointer
              active:bg-gray-300 transition duration-300 ease"> -->

              <li
                class="text-sm px-3 border-gray-400 rounded-full border-2 w-max sm:text-sm md:text-base lg:text-md text-left xl:text-md"
              >
                {{ tag }}
              </li>
            </ul>
          </div>
        </div>

        <div class="w:full md:w-full xl:w-1/3">
          <div class="align-center justify-center">
            <form>
              <div class="flex flex-col align-center justify-center">
                <h1
                  class="text-xl md:text-2xl xl:text-3xl font-bold leading-10 text-gray-800 text-left md:mt-0 mb-4 mt-1 sm:mt-0"
                >
                  Contact
                </h1>
              </div>
              <div class="flex flex-col align-center justify-center">
                <input
                  type="text"
                  class="border border-gray-400 rounded-2xl p-2"
                  placeholder="Full name"
                  v-model="name"
                  required
                />
                <span class="py-1" />

                <input
                  type="text"
                  class="border border-gray-400 rounded-2xl p-2"
                  placeholder="Email"
                  v-model="email"
                  required
                />
                <span class="py-1" />

                <input
                  type="text"
                  class="border border-gray-400 rounded-2xl p-2"
                  placeholder="Phone"
                  v-model="phone"
                />
                <span class="py-1" />

                <input
                  type="text"
                  class="border border-gray-400 rounded-2xl p-2"
                  placeholder="Industry"
                  v-model="industry"
                />
                <span class="py-1" />

                <textarea
                  class="border border-gray-400 rounded-2xl p-2"
                  placeholder="What do you want to talk about?"
                  v-model="message"
                ></textarea>
                <span class="py-1" />

                <input
                  type="file"
                  accept="application/pdf"
                  class="border border-gray-400 bg-white text-gray-400 rounded-2xl p-2"
                  placeholder="Upload CV"
                  required
                />

                <span class="py-1" />
              </div>
              <div class="w-full bottom-0 pt-2 flex justify-end">
                <button
                  class="bg-custom-blue hover:bg-blue-500 text-white px-4 py-1 rounded-3xl text-md shadow-md"
                >
                  Send
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
export default {
  //props: { mentorData: {} },
  name: "MentorDetails",
  data() {
    // console.log(this.mentorData);
    return {
      email: "",
      maxChar: 50,
      mentorData: this.mentorData,
    };
  },
  beforeMount() {
    this.getMentorData();
  },
  methods: {
    sendMessage() {
      console.log(this.name);
      console.log(this.email);
      console.log(this.phone);
      console.log(this.message);
    },
    getMentorData() {
      this.currentURL = window.location.href;
      let counter = 0;
      let i = 0;
      while (counter < 4) {
        i++;
        if (this.currentURL[i] === "/") {
          counter++;
        }
      }
      let str = this.currentURL.slice(i + 1, this.currentURL.length);
      // console.log(this.currentURL, str);

      axios
        .get(
          "https://2d13ac092947-hirelamp-bbcf628a86ebae0f2646300d98508d5.co/expert/profile/" +
            str +
            "/"
        )
        .then((response) => {
          console.log(response.data);
          this.mentorData = response.data;
          // let temp_tags = [];
          // // let j = 0;
          // let temp_str = "";
          // for (const char in response.data.tags) {
          //   while (response.data.tags[char] !== ",") {
          //     temp_str = temp_str + response.data.tags[char];
          //   }
          //   temp_str = "";
          //   temp_tags.push(temp_str);
          //   console.log(temp_tags);
          // }
        });
    },
  },
};
</script>

<style></style>
